import pandas as pd
import asyncio
import argparse

from shared.config import Config
from shared.cohere_client import CohereAsyncClient

def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("--input")
    parser.add_argument("--output")
    args = parser.parse_args()

    df = pd.read_parquet(args.input)

    texts = df.astype(str).agg(" ".join, axis=1).tolist()

    config = Config()
    client = CohereAsyncClient(config)

    vectors = asyncio.run(client.embed(texts))

    pd.DataFrame(vectors).to_parquet(args.output)

if __name__ == "__main__":
    main()
