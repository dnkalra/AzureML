import pandas as pd
import pyodbc
from azure.identity import DefaultAzureCredential

class SQLClient:

    def __init__(self, config):
        self.config = config
        self.credential = DefaultAzureCredential()

    def read_accounts(self):

        token = self.credential.get_token(
            "https://database.windows.net/.default"
        ).token

        conn_str = (
            "DRIVER={ODBC Driver 18 for SQL Server};"
            f"SERVER={self.config.SQL_SERVER};"
            f"DATABASE={self.config.SQL_DB};"
            "Encrypt=yes;"
            "Authentication=ActiveDirectoryAccessToken"
        )

        conn = pyodbc.connect(conn_str, attrs_before={1256: bytes(token,'utf-16-le')})

        return pd.read_sql(f"SELECT * FROM {self.config.SQL_TABLE}", conn)
