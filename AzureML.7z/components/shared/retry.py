import time
import logging

logger = logging.getLogger("retry")

def retry(func, retries=3, delay=2):

    for attempt in range(retries):
        try:
            return func()
        except Exception as e:
            if attempt == retries - 1:
                raise
            logger.warning(f"Retry {attempt+1} due to {e}")
            time.sleep(delay * (attempt+1))
