import faiss

class FaissManager:

    def __init__(self, dim):
        self.dim = dim

    def create_or_update(self, existing_index, vectors):

        if existing_index is None:
            index = faiss.IndexFlatL2(self.dim)
        else:
            index = existing_index

        index.add(vectors)
        return index
