import os

class Config:
    SQL_SERVER = os.getenv("SQL_SERVER")
    SQL_DB = os.getenv("SQL_DB")
    SQL_TABLE = "account"

    EMBED_ENDPOINT = os.getenv("EMBED4_ENDPOINT_URL")
    MODEL = "embed-v4"

    ADLS_ACCOUNT = os.getenv("ADLS_ACCOUNT_NAME")
    ADLS_FILESYSTEM = os.getenv("ADLS_FILESYSTEM")

    VECTOR_DIM = 1024
    BATCH_SIZE = 64
    MAX_RETRIES = 3
