import aiohttp
import asyncio
import numpy as np
from azure.identity import DefaultAzureCredential

class CohereAsyncClient:

    def __init__(self, config):
        self.config = config
        self.credential = DefaultAzureCredential()

    async def _headers(self):
        token = self.credential.get_token(
            "https://cognitiveservices.azure.com/.default"
        ).token
        return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    async def embed_batch(self, session, texts):

        payload = {
            "input": texts,
            "model": self.config.MODEL
        }

        async with session.post(
            self.config.EMBED_ENDPOINT,
            headers=await self._headers(),
            json=payload
        ) as resp:

            resp.raise_for_status()
            data = await resp.json()
            return [d["embedding"] for d in data["data"]]

    async def embed(self, texts):

        headers = await self._headers()

        async with aiohttp.ClientSession(headers=headers) as session:

            tasks = []
            for i in range(0, len(texts), self.config.BATCH_SIZE):
                batch = texts[i:i+self.config.BATCH_SIZE]
                tasks.append(self.embed_batch(session, batch))

            results = await asyncio.gather(*tasks)

        vectors = [v for batch in results for v in batch]
        return np.array(vectors).astype("float32")
