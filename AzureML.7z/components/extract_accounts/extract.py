from shared.config import Config
from shared.sql_client import SQLClient
import pandas as pd
import argparse

def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("--output")
    args = parser.parse_args()

    config = Config()
    sql = SQLClient(config)

    df = sql.read_accounts()
    df.to_parquet(args.output)

if __name__ == "__main__":
    main()
