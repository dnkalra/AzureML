import pandas as pd
import faiss
import argparse
import os

from shared.config import Config
from shared.faiss_utils import FaissManager

def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("--embeddings")
    parser.add_argument("--output")
    args = parser.parse_args()

    config = Config()

    vectors = pd.read_parquet(args.embeddings).values.astype("float32")

    mgr = FaissManager(config.VECTOR_DIM)

    index = mgr.create_or_update(None, vectors)

    faiss.write_index(index, args.output)

if __name__ == "__main__":
    main()
